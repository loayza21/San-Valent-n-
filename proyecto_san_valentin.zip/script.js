function respuesta(opcion) {
    if (opcion === 'sí') {
        alert('¡Sabía que dirías que sí! ❤️');
    } else {
        alert('🥺 Qué sad...');
    }
}
